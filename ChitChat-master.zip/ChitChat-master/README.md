# Chit Chat
(During Reverie Language Hackathon -> 18th January 2020)<br>
Built an android application using the Reverie language hackathon to prevent cyber bullying by analysing the sentiments of the chats in the chat groups.<br>
Used the Reverie language API for:<br>
1) Text to Speech conversion<br>
2) Language translation
